/* ============================================================
   estudiantes.js
   Lógica común de ADD.HTML, UPDATE.HTML y DELETE.HTML.

   Contrato REST que se espera del servidor (ajustar si difiere):
     POST   {API_URL}            body JSON -> crea un estudiante
     GET    {API_URL}/{carnet}   -> devuelve el estudiante (JSON)
     PUT    {API_URL}/{carnet}   body JSON -> actualiza
     DELETE {API_URL}/{carnet}   -> elimina
   Campos JSON (igual que las columnas de la tabla):
     Carnet, Nombres, Apellidos, Fecha_nac (YYYY-MM-DD), Carrera, Correo
   ============================================================ */

const API_URL = "http://localhost/api/estudiantes"; // cambiar puerto/ruta si hace falta

/* ---------- utilidades ---------- */

const $ = (id) => document.getElementById(id);

function mostrarMensaje(texto, tipo) {
  const caja = $("mensaje");
  caja.textContent = texto;
  caja.className = tipo; // "ok" | "error"
}

function limpiarMensaje() {
  const caja = $("mensaje");
  caja.textContent = "";
  caja.className = "";
}

function leerFormulario() {
  return {
    Carnet: $("carnet").value.trim(),
    Nombres: $("nombres").value.trim(),
    Apellidos: $("apellidos").value.trim(),
    Fecha_nac: $("fecha_nac").value,
    Carrera: $("carrera").value.trim(),
    Correo: $("correo").value.trim(),
  };
}

function llenarFormulario(e) {
  $("nombres").value = e.Nombres ?? "";
  $("apellidos").value = e.Apellidos ?? "";
  // MySQL/Node suele devolver "1999-05-03T00:00:00.000Z": nos quedamos con la fecha
  $("fecha_nac").value = e.Fecha_nac ? String(e.Fecha_nac).slice(0, 10) : "";
  $("carrera").value = e.Carrera ?? "";
  $("correo").value = e.Correo ?? "";
}

function validarCarnet(carnet) {
  if (!carnet) return "Escribe el carnet.";
  if (carnet.length > 6) return "El carnet admite máximo 6 caracteres.";
  return null;
}

/* Llamada genérica al servidor; lanza Error con un texto entendible */
async function pedir(url, opciones = {}) {
  let respuesta;
  try {
    respuesta = await fetch(url, {
      headers: { "Content-Type": "application/json" },
      ...opciones,
    });
  } catch (err) {
    throw new Error("No se pudo conectar con el servidor en " + API_URL + ".");
  }

  let datos = null;
  try { datos = await respuesta.json(); } catch (_) { /* respuesta sin cuerpo */ }

  if (!respuesta.ok) {
    const detalle = datos && (datos.mensaje || datos.message || datos.error);
    if (respuesta.status === 404) throw new Error("No existe un estudiante con ese carnet.");
    if (respuesta.status === 409) throw new Error("Ya existe un estudiante con ese carnet.");
    throw new Error(detalle || "El servidor respondió con el error " + respuesta.status + ".");
  }
  return datos;
}

const url = (carnet) => API_URL + "/" + encodeURIComponent(carnet);

/* ---------- ADD.HTML ---------- */

function iniciarAdd() {
  $("formulario").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    limpiarMensaje();

    const est = leerFormulario();
    const error = validarCarnet(est.Carnet);
    if (error) return mostrarMensaje(error, "error");

    $("guardar").disabled = true;
    try {
      await pedir(API_URL, { method: "POST", body: JSON.stringify(est) });
      mostrarMensaje("Estudiante " + est.Carnet + " agregado.", "ok");
      $("formulario").reset();
      $("carnet").focus();
    } catch (err) {
      mostrarMensaje(err.message, "error");
    } finally {
      $("guardar").disabled = false;
    }
  });
}

/* ---------- UPDATE.HTML ---------- */

function activarCamposEdicion(activo) {
  ["nombres", "apellidos", "fecha_nac", "carrera", "correo"].forEach((id) => {
    $(id).disabled = !activo;
  });
  $("guardar").disabled = !activo;
}

function iniciarUpdate() {
  activarCamposEdicion(false);

  // Paso 1: buscar por carnet y cargar los datos actuales
  $("buscar").addEventListener("click", async () => {
    limpiarMensaje();
    activarCamposEdicion(false);

    const carnet = $("carnet").value.trim();
    const error = validarCarnet(carnet);
    if (error) return mostrarMensaje(error, "error");

    try {
      const est = await pedir(url(carnet));
      llenarFormulario(est);
      activarCamposEdicion(true);
      $("nombres").focus();
      mostrarMensaje("Datos cargados. Edita lo que necesites y guarda.", "ok");
    } catch (err) {
      $("nombres").form.querySelectorAll("input:not(#carnet)").forEach((i) => (i.value = ""));
      mostrarMensaje(err.message, "error");
    }
  });

  // Si cambia el carnet, se obliga a buscar de nuevo
  $("carnet").addEventListener("input", () => activarCamposEdicion(false));

  // Paso 2: guardar los cambios
  $("formulario").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    limpiarMensaje();

    const est = leerFormulario();
    $("guardar").disabled = true;
    try {
      await pedir(url(est.Carnet), { method: "PUT", body: JSON.stringify(est) });
      mostrarMensaje("Estudiante " + est.Carnet + " actualizado.", "ok");
    } catch (err) {
      mostrarMensaje(err.message, "error");
    } finally {
      $("guardar").disabled = false;
    }
  });
}

/* ---------- DELETE.HTML ---------- */

function mostrarFicha(e) {
  const fecha = e.Fecha_nac ? String(e.Fecha_nac).slice(0, 10) : "—";
  $("ficha").innerHTML =
    "<dl>" +
    "<dt>Carnet</dt><dd></dd>" +
    "<dt>Nombre</dt><dd></dd>" +
    "<dt>Fecha de nacimiento</dt><dd></dd>" +
    "<dt>Carrera</dt><dd></dd>" +
    "<dt>Correo</dt><dd></dd>" +
    "</dl>";
  // textContent evita inyectar HTML con datos que vienen de la base
  const celdas = $("ficha").querySelectorAll("dd");
  celdas[0].textContent = e.Carnet ?? "";
  celdas[1].textContent = ((e.Nombres ?? "") + " " + (e.Apellidos ?? "")).trim();
  celdas[2].textContent = fecha;
  celdas[3].textContent = e.Carrera ?? "—";
  celdas[4].textContent = e.Correo ?? "—";
  $("ficha").style.display = "block";
}

function iniciarDelete() {
  $("eliminar").disabled = true;

  // Paso 1: buscar para confirmar visualmente qué se va a borrar
  $("buscar").addEventListener("click", async () => {
    limpiarMensaje();
    $("ficha").style.display = "none";
    $("eliminar").disabled = true;

    const carnet = $("carnet").value.trim();
    const error = validarCarnet(carnet);
    if (error) return mostrarMensaje(error, "error");

    try {
      const est = await pedir(url(carnet));
      mostrarFicha(est);
      $("eliminar").disabled = false;
    } catch (err) {
      mostrarMensaje(err.message, "error");
    }
  });

  $("carnet").addEventListener("input", () => {
    $("ficha").style.display = "none";
    $("eliminar").disabled = true;
  });

  // Paso 2: eliminar tras confirmar
  $("formulario").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    limpiarMensaje();

    const carnet = $("carnet").value.trim();
    if (!confirm("¿Eliminar al estudiante " + carnet + "? Esta acción no se puede deshacer.")) return;

    $("eliminar").disabled = true;
    try {
      await pedir(url(carnet), { method: "DELETE" });
      mostrarMensaje("Estudiante " + carnet + " eliminado.", "ok");
      $("ficha").style.display = "none";
      $("formulario").reset();
      $("carnet").focus();
    } catch (err) {
      mostrarMensaje(err.message, "error");
      $("eliminar").disabled = false;
    }
  });
}

/* ---------- LIST.HTML ---------- */

async function cargarTabla() {
  limpiarMensaje();
  const cuerpo = $("cuerpo");
  cuerpo.innerHTML = "";

  try {
    const estudiantes = await pedir(API_URL);

    if (estudiantes.length === 0) {
      mostrarMensaje("Aún no hay estudiantes registrados.", "ok");
      $("total").textContent = "0 estudiantes";
      return;
    }

    const campos = ["Carnet", "Nombres", "Apellidos", "Fecha_nac", "Carrera", "Correo"];
    estudiantes.forEach((e) => {
      const fila = document.createElement("tr");
      campos.forEach((campo) => {
        const celda = document.createElement("td");
        let valor = e[campo] ?? "";
        if (campo === "Fecha_nac" && valor) valor = String(valor).slice(0, 10);
        celda.textContent = valor; // textContent evita inyectar HTML
        fila.appendChild(celda);
      });
      cuerpo.appendChild(fila);
    });

    $("total").textContent = estudiantes.length + (estudiantes.length === 1 ? " estudiante" : " estudiantes");
  } catch (err) {
    mostrarMensaje(err.message, "error");
  }
}

function iniciarList() {
  $("actualizar").addEventListener("click", cargarTabla);
  cargarTabla();
}

/* ---------- arranque: cada página declara su acción en <body data-pagina> ---------- */

document.addEventListener("DOMContentLoaded", () => {
  const pagina = document.body.dataset.pagina;
  if (pagina === "list") iniciarList();
  if (pagina === "add") iniciarAdd();
  if (pagina === "update") iniciarUpdate();
  if (pagina === "delete") iniciarDelete();
});
