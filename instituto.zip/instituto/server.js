/* ============================================================
   server.js - API REST para INSTITUTO.ESTUDIANTES

   Rutas (las mismas que usa estudiantes.js):
     POST   /api/estudiantes
     GET    /api/estudiantes/:carnet
     PUT    /api/estudiantes/:carnet
     DELETE /api/estudiantes/:carnet

   También sirve los formularios desde la carpeta "public",
   así que puedes abrir http://localhost/ADD.HTML
   ============================================================ */

const express = require("express");
const cors = require("cors");
const mysql = require("mysql2/promise");
const path = require("path");

/* ---------- configuración (cambia estos valores o usa variables de entorno) ---------- */

const PORT = process.env.PORT || 80; // 80 = http://localhost sin puerto
const DB = {
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "basico1",
  password: process.env.DB_PASSWORD || "Merciso1-",
  database: process.env.DB_NAME || "INSTITUTO",
};

/* ---------- conexión ---------- */

const pool = mysql.createPool({
  ...DB,
  waitForConnections: true,
  connectionLimit: 5,
  dateStrings: true, // DATE llega como "YYYY-MM-DD", sin problemas de zona horaria
});

/* ---------- app ---------- */

const app = express();
app.use(cors()); // permite abrir los HTML desde file:// u otro puerto
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

/* ---------- utilidades ---------- */

// Convierte el cuerpo recibido en valores listos para MySQL ("" -> NULL)
function limpiar(body) {
  const vacioANull = (v) => (v === undefined || v === null || String(v).trim() === "" ? null : String(v).trim());
  return {
    Carnet: vacioANull(body.Carnet),
    Nombres: vacioANull(body.Nombres),
    Apellidos: vacioANull(body.Apellidos),
    Fecha_nac: vacioANull(body.Fecha_nac),
    Carrera: vacioANull(body.Carrera),
    Correo: vacioANull(body.Correo),
  };
}

// Valida longitudes según la estructura de la tabla
function validar(e) {
  if (!e.Carnet) return "El carnet es obligatorio.";
  if (e.Carnet.length > 6) return "El carnet admite máximo 6 caracteres.";
  if (e.Nombres && e.Nombres.length > 50) return "Nombres admite máximo 50 caracteres.";
  if (e.Apellidos && e.Apellidos.length > 50) return "Apellidos admite máximo 50 caracteres.";
  if (e.Carrera && e.Carrera.length > 50) return "Carrera admite máximo 50 caracteres.";
  if (e.Correo && e.Correo.length > 25) return "Correo admite máximo 25 caracteres.";
  if (e.Fecha_nac && !/^\d{4}-\d{2}-\d{2}$/.test(e.Fecha_nac)) return "Fecha_nac debe tener formato AAAA-MM-DD.";
  return null;
}

function errorServidor(res, err) {
  console.error(err);
  res.status(500).json({ mensaje: "Error en el servidor o en la base de datos." });
}

/* ---------- rutas ---------- */

// Agregar
app.post("/api/estudiantes", async (req, res) => {
  const e = limpiar(req.body);
  const error = validar(e);
  if (error) return res.status(400).json({ mensaje: error });

  try {
    await pool.execute(
      "INSERT INTO ESTUDIANTES (Carnet, Nombres, Apellidos, Fecha_nac, Carrera, Correo) VALUES (?, ?, ?, ?, ?, ?)",
      [e.Carnet, e.Nombres, e.Apellidos, e.Fecha_nac, e.Carrera, e.Correo]
    );
    res.status(201).json(e);
  } catch (err) {
    if (err.code === "ER_DUP_ENTRY") return res.status(409).json({ mensaje: "Ya existe un estudiante con ese carnet." });
    errorServidor(res, err);
  }
});

// Buscar por carnet
app.get("/api/estudiantes/:carnet", async (req, res) => {
  try {
    const [filas] = await pool.execute("SELECT * FROM ESTUDIANTES WHERE Carnet = ?", [req.params.carnet]);
    if (filas.length === 0) return res.status(404).json({ mensaje: "No existe un estudiante con ese carnet." });
    res.json(filas[0]);
  } catch (err) {
    errorServidor(res, err);
  }
});

// Actualizar
app.put("/api/estudiantes/:carnet", async (req, res) => {
  const e = limpiar({ ...req.body, Carnet: req.params.carnet }); // el carnet manda la URL
  const error = validar(e);
  if (error) return res.status(400).json({ mensaje: error });

  try {
    const [r] = await pool.execute(
      "UPDATE ESTUDIANTES SET Nombres = ?, Apellidos = ?, Fecha_nac = ?, Carrera = ?, Correo = ? WHERE Carnet = ?",
      [e.Nombres, e.Apellidos, e.Fecha_nac, e.Carrera, e.Correo, e.Carnet]
    );
    if (r.affectedRows === 0) return res.status(404).json({ mensaje: "No existe un estudiante con ese carnet." });
    res.json(e);
  } catch (err) {
    errorServidor(res, err);
  }
});

// Eliminar
app.delete("/api/estudiantes/:carnet", async (req, res) => {
  try {
    const [r] = await pool.execute("DELETE FROM ESTUDIANTES WHERE Carnet = ?", [req.params.carnet]);
    if (r.affectedRows === 0) return res.status(404).json({ mensaje: "No existe un estudiante con ese carnet." });
    res.json({ mensaje: "Estudiante eliminado." });
  } catch (err) {
    errorServidor(res, err);
  }
});

/* ---------- arranque ---------- */

pool
  .query("SELECT 1")
  .then(() => {
    app.listen(PORT, () => console.log("Servidor listo en http://localhost" + (PORT == 80 ? "" : ":" + PORT)));
  })
  .catch((err) => {
    console.error("No se pudo conectar a MySQL:", err.message);
    process.exit(1);
  });
